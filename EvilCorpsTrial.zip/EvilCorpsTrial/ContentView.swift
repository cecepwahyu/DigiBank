//
//  ContentView.swift
//  EvilCorpsTrial
//
//  Created by Cecep on 12/10/23.
//

import SwiftUI

let Primary = Color(#colorLiteral(red: 0.9520882964, green: 0.9689558148, blue: 0.9943284392, alpha: 1))
let Secondary = Color(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1))
let ButtonColor = Color(#colorLiteral(red: 0.424377799, green: 0.3887372613, blue: 0.9981479049, alpha: 1))

//

struct ContentView: View {
    var body: some View {
        //Login()
        Rekening()
    }
}

struct Login: View {
    
    @State var username : String = ""
    @State var password : String = ""
    
    let lightGreyColor = Color(red : 239.0/255.0, green: 243.0/255.0, blue: 244.0/255/0, opacity: 1.0)
    
    var body: some View {
        ZStack {
            Color(.primary)
                .edgesIgnoringSafeArea(.all)
            VStack {
                Image(systemName: "xbox.logo")
                    .resizable()
                    .frame(width: 100, height: 100)
                    .foregroundColor(ButtonColor)
                ZStack {
                    Rectangle()
                        .frame(height: 500)
                        .foregroundColor(Secondary)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .padding()
                    
                    VStack(alignment: .leading) {
                        HStack {
                            Text("Login")
                                .bold()
                                .font(.title2)
                                .padding([.top, .bottom], 5)
                        }
                        //.padding()
                        
                        Text("Silahkan memasukkan username dan password terdaftar anda untuk melakukan login")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        .padding([.top, .bottom], 5)
                        
                        //Field Username
                        Text("Username :")
                            .bold()
                        TextField("Username", text: $username)
                            .padding()
                            .background(lightGreyColor)
                            .cornerRadius(5.0)
                        
                        //Field Password
                        Text("Password :")
                            .bold()
                        TextField("Password", text: $password)
                            .padding()
                            .background(lightGreyColor).cornerRadius(5.0)
                        
                        //Lupa Password Button
                        HStack {
                            Spacer()
                            Button(action: {}) {
                                Text("Lupa Username / Password ?")
                                    .font(.callout)
                                    .foregroundColor(ButtonColor)
                                    .padding([.top, .bottom], 10)
                            }
                            
                        }
                        
                        //Login Button
                        HStack {
                            Spacer()
                            Button(action: {}) {
                                Text("Login")
                                    .bold()
                                    .foregroundColor(.white)
                            }
                            Spacer()
                        }
                        .padding()
                        .background(ButtonColor)
                        .cornerRadius(15)
                        
                        
                        //Register Button
                        HStack {
                            Spacer()
                            Text("Belum punya akun?")
                            
                            Button(action: {}) {
                                Text("Daftar")
                                    .foregroundColor(ButtonColor)
                            }
                            Spacer()
                        }
                        .padding()
                        
                            
                    }
                    .padding([.leading, .trailing], 40)
                }
            
            }
        }
    }
}

struct Rekening : View {
    var body: some View {
        ZStack {
            Color(.primary)
                .edgesIgnoringSafeArea(.all)
            VStack {
                HStack {
                    Button(action: {}) {
                        ZStack {
                            Circle()
                                .frame(width: 35, height: 35)
                                .foregroundColor(ButtonColor)
                            Image(systemName: "chevron.backward")
                                .foregroundColor(.white)
                                .bold()
                        }
                    }
                    
                    Spacer()
                    
                    Text("Buat Akun")
                        .font(.title2)
                        .bold()
                    
                    Spacer()
                    
                }
                .padding()
                
                ZStack {
                    Rectangle()
                        .frame(height: 500)
                        .foregroundColor(Secondary)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .padding()
                    
                    VStack {
                        Text("Informasi Data Diri")
                            .font(.title2)
                    }
                }
                
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
